// LAMBDA TEMPLATES

//example
// int a [] = {1, 2, 3, 4, 5};
// int b [] = (6, 7, 8, 9, 10};
//
// scalar product of a and b is
// 1 * 6 + 2 * 7 + 3 * 6 + 4 * 9 + 5 * 10 = 130

//Interface
interface MyOperation
{
	int operation (int a, int b);
}


class ScalarProduct
{
	static int sp (int []a, int [] b)
	{
		//insert for loop to do the SCALAR product 
		//example
		int sumProduct = 0;
		for (int i = 0; i < a.length; i++)
			sumProduct = op1.operation (sumProduct,
									op2.operation (a [i], b [i]));
		return sumProduct;
	}
	
	public static void main (String [] args)
	{
	//list the arrays
	int a [] = {1, 2, 3, 4, 5};
	int b [] = {6, 7, 8, 9, 10};
	
	System.out.println ("(I) Scalar product is " + sp (a, b));
	
	//Use of lamda expression to implement the interface
	// (parametersList -> [statements])
	MyOperation plus = (int x, int y) -> x + y;
	// (parametersList -> [statements])
	MyOperation times = (x, y) -> x * y;
	System.out.println ("(II) Scalar product is " + sp (a, b, plus, times));
	}
}
	
// Same example from above (but using BigInteger Class)
//Package java.math provides classes BigInteger 
// explicitly for arbitrary precision calculations that 
//cannot be performed with primitive types.

import java.math.BigInteger;
interface MyOperation
{
	BigInteger operation (BigInteger a, BigInteger b);
}

class ScalarProduct
{
	static int sp (int []a, int [] b)
	{
		//insert for loop to do the SCALAR product 
		//example
		int sumProduct = 0;
		for (int i = 0; i < a.length; i++)
			sumProduct = sumProduct + a [i] * b [i];		
		return sumProduct;
	}
	
	static BigInteger sp (int [] a, int [] b, MyOperation op1, MyOperation op2)
	{
		BigInteger sumProduct = BigInteger.ZERO;
		for (int i = 0; i < a.length; i++)
		{
			BigInteger temp1 = BigInteger.valueOf (a [i]);
			BigInteger temp2 = BigInteger.valueOf (b [i]);
			sumProduct = op1.operation (sumProduct,
			op2.operation (temp1, temp2));
		}
		return sumProduct;
	}
	
	public static void main (String [] args)
	{
		int a [] = {1, 2, 3, 4, 5};
		int b [] = {6, 7, 8, 9, 10};
		System.out.println ("(I) Scalar product is " + sp (a, b));
		// Use of lambda expression to implements the interface
		MyOperation plus = (BigInteger x, BigInteger y) -> x.add (y);
		MyOperation times = (BigInteger x, BigInteger y) -> x.multiply (y);
		System.out.println ("(II) Scalar product is " + sp (a, b, plus, times));
	}
}

// the use of IntStream
import java.util.stream.IntStream;
import java.util.IntSummaryStatistics;
class TestIntStream
{
	static int a [] = {2, 4, 5, -6, 1, -8, 5, 7, 9, 2};
	
	static void example_1()
	{
		//this is to print the arrays
		IntStream.of (a)
					.forEach (n -> S
		System.out.println ();
		
		//this is to get no. of element in the arrays
		long count = IntStream.of (a)
								.count ();
		System.out.println ("No of array elements is " + count);
		
		//this is to find the sum of all number in the arrays
		long sum = IntStream.of (a)
								.sum ();
		System.out.println ("Sum of array elements is " + sum);
		
		//to find the average of all the array elements
		double average = IntStream.of(a)
									.average()
									.getAsDouble();
		System.out.println ("The average is " + average);							
		
		//to display the Summary of statistics 
		//eg.intsummarystatics (count=10,sum21, etc..)
		IntSummaryStatistics s = IntStream.of (a)
											.summaryStatistics ();
		System.out.println (s);
		
		// to find the sum of square of each the element in array
		int sumSquare = IntStream.of (a)
									.reduce (0, (x, y) -> x + y * y);	
		System.out.println ("Sum of squares = " + sumSquare);
		
		// this is to add all negative numbers in array
		int sumNegative = IntStream.of (a)
									.filter (x -> x < 0)
									.sum ();
		System.out.println ("Sum of negative numbers only is " +sumNegative);
		
		//this is to count the number of distinct positive integers
		// the duplicated one isnt counted
		long countPositive = IntStream.of (a)
										.filter (x -> x > 0)
										.distinct ()
										.count ();
		System.out.println ("Distinct and positive count is " + countPositive);
		
		
		//this is to take the square of each elements then sort the array
		
		IntStream.of (a)
					.map (x -> x * x)
					.sorted ()
					.forEach (x -> System.out.printf ("%d ", x));
		System.out.println ();
		
		
		//If questions ask to find sum from 1 to n and many more
		
		// if the upperbound n is exclusive 
		int sum1ToN = IntStream.range (1, n)
					.sum ();
		System.out.println ("Sum 1 to 10 is " + sum1ToN);
		
		// if the upperbound n is inclusive
		int sum1ToNN = IntStream.rangeClosed (1, n)
					.sum ();
		System.out.println ("Sum 1 to 10 is " + sum1ToNN);
		
		// the total sum of all odd digits from 1 to n (inclusive)
		int sumOdd = IntStream.rangeClosed (1, n)
				.filter (x -> x % 2 == 1)
				.sum ();
		System.out.println ("Sum of odd digits = " + sumOdd);
	}
}