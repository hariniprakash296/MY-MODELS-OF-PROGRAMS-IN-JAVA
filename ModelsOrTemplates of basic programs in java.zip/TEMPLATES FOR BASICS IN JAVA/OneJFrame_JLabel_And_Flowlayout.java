// Objective: The use of JOptionPane for dialog and display 
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.FlowLayout;

class OneJFrame_JLabel_And_Flowlayout
{
 public static void main (String [] args)
 {
	JFrame af = new JFrame ("My First Frame");
	af.setSize (250, 100);
	af.setVisible (true);

	af.setLayout (new FlowLayout ());

	JLabel label_1 = new JLabel ("Welcome to 121");
	// Add the labels to the frame 
	af.add (label_1);
 }
}