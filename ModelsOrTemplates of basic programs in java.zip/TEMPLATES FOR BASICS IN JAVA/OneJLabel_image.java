// Objective: The use of JOptionPane for dialog and display 
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.FlowLayout;
import javax.swing.Icon; // interface used to manipulate images 
import javax.swing.ImageIcon; // loads images
import javax.swing.SwingConstants; // common constants used with Swing 

class OneJLabel_image extends JFrame
{
	
	
 public static void main (String [] args)
 {
	JFrame af = new JFrame ("My First Frame");
	af.setSize (250, 100);
	af.setVisible (true);

	af.setLayout (new FlowLayout ());

	JLabel label2; // JLabel constructed with text and icon 
	Icon b = new ImageIcon ("1.jpg");
	label2 = new JLabel ("Picture b", b, SwingConstants.LEFT);
	af.add (label2);
 }
}