//Templates to use for finals

//1.base of a program
import java.util.Scanner;
class ClassName
{
	//declaring instance variables (declared as private to demonstrate encapsulation)
	private int a;
	private int b;
	
	//Normal constructor to initialise variables
	public ClassName(int a,int b)
	{
		this.a = a;
		this.b = b;
	}
	
	//copy constructor
	public ClassName(ClassName d)
	{
		this.a=d.a;
		this.b=d.b;
	}
	
	//accessor methods
	public int getA()
	{
		return a;
	}
	public int getB()
	{
		return b;
	}
	
	//setting information
	public void setInfo(int a, int b)
	{
		this.a = a;
		this.b = b;
	}
	private boolean isequal()
	{
		//condition ? pass : fail
		return (a == b) ? true : false;
	}
	
	//method to display information
	public void displayInfo()
	{
		System.out.printf("A: %s%n",a);
		System.out.printf("B: %d%n",b);
		System.out.printf("The condition is: %s%n",isequal());
	}
}

public class boolean_checker
{
	public static void main (String [] args)
	{
		//getting input from user using Scanner
		Scanner input = new Scanner(System.in);
		//Asking user for input
		System.out.printf("Enter an Integer:");
		//We give input.nextLine() to read an entire string and input.next() to read one character alone
		int a = input.nextInt();
		
		System.out.printf("Enter an Integer:");
		int b = input.nextInt();
		
		ClassName Hello = new ClassName(a,b);
		Hello.displayInfo();
	}
}
