//###########################################################################################################################################


import javax.swing.JOptionPane;
class JOP_displayString 
{
 public static void main (String [] args)
 {
	String str = JOptionPane.showInputDialog ("Display this before textbox");
	String a = str; 
	str = "Display in message dialogue " + a;
 
	// Display the output dialog box 
	JOptionPane.showMessageDialog (null, str, "Rectangle example",JOptionPane.INFORMATION_MESSAGE);
 
 } // end of main 
} // end of class


//###########################################################################################################################################

// Objective: The use of JOptionPane for dialog and display 
// What happen if error occurs? 
// 
import javax.swing.JOptionPane;
import java.lang.NumberFormatException;
class JOP_displayDoublewithException handling
{
 public static void main (String [] args)
 {
	try
	{
		String str = JOptionPane.showInputDialog (
		"Enter the length and press OK");
		double length = Double.parseDouble (str);
 
		str = "Given length = " + length;
 
		// Display the output dialog box 
		JOptionPane.showMessageDialog (null, str, "Text message",JOptionPane.INFORMATION_MESSAGE);
	}
	catch (NumberFormatException e)
	{
		JOptionPane.showMessageDialog (null, "Number format problem","Error message",JOptionPane.ERROR_MESSAGE);
	}
	finally
	{
		JOptionPane.showMessageDialog (null, "I hope you enjoy this example","Welcome back",JOptionPane.INFORMATION_MESSAGE);
	}
 
 } // end of main 
} // end of class

//###########################################################################################################################################

// Objective: The use of JOptionPane for dialog and display 
import javax.swing.JFrame;
class J_Frame_only 
{
 public static void main (String [] args)
 {
	JFrame aFrame = new JFrame ("My First Frame");
	aFrame.setSize (250, 100);
	aFrame.setVisible (true);
 }
}

//###########################################################################################################################################

// Objective: The use of JOptionPane for dialog and display 
import javax.swing.JFrame;
import javax.swing.JLabel;

class OneJFrame_OneJLabel
{
 public static void main (String [] args)
 {
	JFrame af = new JFrame ("My First Frame");
	af.setSize (250, 100);
	af.setVisible (true);

	JLabel label_1 = new JLabel ("Welcome to 121");
	// Add the labels to the frame 
	af.add (label_1);
 }
}


//###########################################################################################################################################

// Objective: The use of JOptionPane for dialog and display 
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.FlowLayout;
import javax.swing.Icon; // interface used to manipulate images 
import javax.swing.ImageIcon; // loads images
import javax.swing.SwingConstants; // common constants used with Swing 

class OneJLabel_image extends JFrame
{
	
	
 public static void main (String [] args)
 {
	JFrame af = new JFrame ("My First Frame");
	af.setSize (250, 100);
	af.setVisible (true);

	af.setLayout (new FlowLayout ());

	JLabel label2; // JLabel constructed with text and icon 
	Icon b = new ImageIcon ("1.jpg");
	label2 = new JLabel ("Picture b", b, SwingConstants.LEFT);
	af.add (label2);
 }
}

//###########################################################################################################################################

// Objective: The use of JOptionPane for dialog and display 
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.FlowLayout; 
import java.awt.Color;
import java.awt.Font;

class Setting_FontAndColour extends JFrame
{
	
	
 public static void main (String [] args)
 {
	JFrame af = new JFrame ("My First Frame");
	af.setSize (250, 100);
	af.setVisible (true);

	af.setLayout (new FlowLayout ());

	JLabel label2; // JLabel constructed with text
	label2 = new JLabel ("Picture b");

	//import java.awt.Font;
	label2.setFont (new Font ("Arial", Font.BOLD, 50));
	//import java.awt.Color;
	label2.setForeground (Color.red);

	af.add (label2);
	
	//setting 
 }
}

//###########################################################################################################################################

// Objective: The use of JOptionPane for dialog and display 
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.FlowLayout; 
import javax.swing.JButton;

class buttons extends JFrame
{
 public buttons()
 {
	super ("buttons");
	setLayout (new FlowLayout ());
	add (new JButton ("JButton 1"));
	
	setSize (200, 300);
	setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
	setVisible (true);
 }
}

class creating_JButton
{
 public static void main (String [] args)
 {
	buttons BUTTON = new buttons();
 }
}

//###########################################################################################################################################

// Objective: The use of JOptionPane for dialog and display 
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.FlowLayout; 
import javax.swing.JCheckBox;

class buttons extends JFrame
{
 public buttons()
 {
	super ("buttons");
	setLayout (new FlowLayout ());
	add (new JCheckBox ("JCheckBox 1"));
	
	setSize (200, 300);
	setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
	setVisible (true);
 }
}

class creating_JCheckBoxButton
{
 public static void main (String [] args)
 {
	buttons BUTTON = new buttons();
 }
}

//###########################################################################################################################################

// Objective: The use of JOptionPane for dialog and display 
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.FlowLayout; 
import javax.swing.JRadioButton;

class buttons extends JFrame
{
 public buttons()
 {
	super ("buttons");
	setLayout (new FlowLayout ());
	add (new JRadioButton ("JRadio Button 1"));
	
	setSize (200, 300);
	setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
	setVisible (true);
 }
}

class creating_RadioButton
{
 public static void main (String [] args)
 {
	buttons BUTTON = new buttons();
 }
}

//###########################################################################################################################################

//button layout----------------->flowlayout
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.FlowLayout; 
import javax.swing.JButton;

class TestGridLayout extends JFrame 
{
 public TestGridLayout (String s)
 {
 super (s);
 setSize (200, 100);
 // only thing that changes from flowlayout
 setLayout (new GridLayout (3, 4));

 //loop to add as many buttons as needed
 for (int i = 1; i <= 6; i++)
 {
 add (new JButton ("Button's names " + i));
 }
 
 setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
 setVisible (true);
 } 
}


class Button_GridLayout
{
 public static void main (String [] args)
 {
	TestGridLayout BUTTON = new TestGridLayout("Title");
 }
}

//###########################################################################################################################################

//button layout----------------->flowlayout
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.GridLayout; 
import javax.swing.JButton;

class TestGridLayout extends JFrame 
{
 public TestGridLayout (String s)
 {
 super (s);
 setSize (200, 100);
 // only thing that changes from flowlayout
 setLayout (new GridLayout (3, 4));

 //loop to add as many buttons as needed
 for (int i = 1; i <= 6; i++)
 {
 add (new JButton ("Button's names " + i));
 }
 
 setDefaultCloseOperation (JFrame.EXIT_ON_CLOSE);
 setVisible (true);
 } 
}


class Button_GridLayout
{
 public static void main (String [] args)
 {
	TestGridLayout BUTTON = new TestGridLayout("Title");
 }
}

//###########################################################################################################################################
