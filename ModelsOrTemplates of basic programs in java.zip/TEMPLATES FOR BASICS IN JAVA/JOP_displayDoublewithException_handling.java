// Objective: The use of JOptionPane for dialog and display 
// What happen if error occurs? 
// 
import javax.swing.JOptionPane;
import java.lang.NumberFormatException;
class JOP_displayDoublewithException_handling
{
 public static void main (String [] args)
 {
	try
	{
		String str = JOptionPane.showInputDialog (
		"Enter the length and press OK");
		double length = Double.parseDouble (str);
 
		str = "Given length = " + length;
 
		// Display the output dialog box 
		JOptionPane.showMessageDialog (null, str, "Text message",JOptionPane.INFORMATION_MESSAGE);
	}
	catch (NumberFormatException e)
	{
		JOptionPane.showMessageDialog (null, "Number format problem","Error message",JOptionPane.ERROR_MESSAGE);
	}
	finally
	{
		JOptionPane.showMessageDialog (null, "Finally","Block",JOptionPane.INFORMATION_MESSAGE);
	}
 
 } // end of main 
} // end of clas