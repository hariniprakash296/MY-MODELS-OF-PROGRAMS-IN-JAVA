import java.io.IOException;
import java.io.FileNotFoundException;
import java.util.Formatter;
import java.lang.SecurityException;
import java.util.Scanner;
import java.util.NoSuchElementException;
import java.nio.file.Paths;

public class TextFileProcessing
{
	static Formatter output;
	static Scanner input;
	static Person [] p = {new Person ("Tan Ah Beng", 23, 'M'),
					new Person ("Lily Wong", 21, 'F'),
					new Person ("Robert Tan", 33, 'M'),
					new Person ("Nancy Lim", 25, 'F')};
	
	static void createTextFile(String fileName)
	{
		//OPENING THE fileName
	try
	{
		output = new formatter(fileName);
	}
	catch (FileNotFoundException e)
	{
		System.err.println("File could not open for creation");
		System.exit(1);
	}
	
	catch(SecurityException e)
	{
		System.err.println("Write permission denied")
		//System.exit(0) or EXIT_SUCCESS;  ---> Success
		//System.exit(1) or EXIT_FAILURE;  ---> Exception
		// System.exit(-1) or EXIT_ERROR;   ---> Error
		System.exit(1);
	}
	finally
	{
		System.out.println("With or without errors, we continue");
	}
	System.out.println(fileName + "opened for creation OK");
	
	//to Create the data file
	for (Person k : p)
	{
		output.format("%s%n",k);
		System.out.println("Added" + k.getName() + "to file");
	}
	
	//to close the file
	if (output != null)
	{
		output.close();
		System.out.println(fileName + "successfully create");
	}


	//opening the file for reading
	static void processTextFile(String fileName)
	{
		try
		{	
			input = new Scanner (Paths.get (fileName));
		}
		catch (FileNotFoundException e)
		{
			System.err.println ("Error in open the file");
			System.exit (-1);
		}
		catch (IOException e)
		{
			System.err.println ("Error in IO");
			System.exit (1);
		}
		System.out.println ("Begin processing of " + fileName);
		
		// processing the input file
		try 
		{
			while (input.hasNext())
			{
				String name = input.nextLine();
				int age = input.nextInt();
				char gender = input.next().charAt(0);
				input.nextLine();
				
				System.out.println("Person ("+ name + "," + age + "," + gender + ")");
			}
		}
		catch (NoSuchElementException e)
		{
			System.err.println("No such element exeception caught");
			System.exit(1);
		}
		
		// To close the file
		if (input != null)
		{
			input.close();
			System.out.println(fileName + "closed for reading");
		}
	}
	public static void main (String [] args)
	{
		//CREATING AND PROCESSING TEXTFILE
		createTextFile ("infile.txt");
		processTextFile("infile.txt");
	}
}
	
class Person
{
	private String name;
	private int age;
	private char gender;
	
	public Person (String name
	{
		this.name = name;
		if (age <= 0 || age >= 150)
			throw new IllegalArgumentException ("Ridiculous age");
		
		this.age = age;
		if (gender != 'M' || gender != 'm' || gender != 'F' || gender != 'f')
			throw new IllegalArgumentException ("Wrong gender");
		
		this.gender = gender;
			
	}

	public String getName ()
	{
		return name;
	}
	public int age ()
	{
		return age;
	}
	public char getGender ()
	{
		return gender;
	}
	public String toString ()
	{
		return String.format ("%-20s%n%d %c", name, age, gender);
	}
}

//Output 
/* infile.txt opened for creation OK
Added Tan Ah Beng to File 
Added Lilly wong to file
.
.
infile.txt successfully create
begin processing of infile.txt
Person (Tan Ah Beng,        , 23, M)
Person (Lilly wong,        , 22, F)
.
.
infile.txt closed for reading
		 */

//Another example 
import java.io.Serializable;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.io.IOException;
public class ObjectFileProcessing
{
	static Person [] p = {new Person ("James Lim", 20, 'M'),
				new Person ("Robert Tan", 23, 'M'),
				new Person ("Lily Ling", 18, 'F')};
	static Student [] s = {new Student ("Richard Lim", 20, 'M', "Security"),
				new Student ("Rob Tan", 13, 'M', "Multimedia"),
				new Student ("Lily Lin", 28, 'F', "Big Data")};
				
	
	
	static ObjectOutputStream output;
	static ObjectInputStream input;
	
	static void createObjectFile (String fileName)
	{
		//Open the file
		try
		{
			output = new ObjectOutputStream (Files.newOutputStream (
									Path.get(fileName));
		}
		catch (IO Exception e)
		{
			System.err.println ("Errors in IO");
			System.exit (1);
		}
		catch (SecurityException e)
		{
			System.err.println ("Write permission denied");
			System.exit (1);
		}
		System.out.println("Begin the creation of Serializable file");
		
		try 
		{
			for (Person k:p)
			{
				// writing something in the file
				output.writeObject(k);
				System.out.println("Added person" + k.getName());
			}
			
			for (Student k:s)
			{
				// writing something in the file
				output.writeObject(k);
				System.out.println("Added student" + k.getName());
			}
		}
		catch (IOException e)
		{
			System.err.println("Problem in IO write objects");
		}
		
		//closing the file
		try
		{
			if (output != null)
			{
			output.close ();
			System.out.println ("Serializabvle file " +
				fileName + " created");
			}
		}
		catch (IOException e)
		{
			System.err.println ("IO error in closing file");
			System.exit (1);
		}
	}
	
	static void processObjectFile (String fileName)
	{
	// Opening the file
		try
		{
			input = new ObjectInputStream (Files.newInputStream (
						Paths.get (fileName)));
		}
		catch (IOException e)
		{
			System.err.println ("Errors in open file for processing");
		}
		System.out.println ("\nBegin the process of " + fileName);
		
	/*
	A <-- B <-- C <-- D
	B extends A
	C extends B
	D extends C
	*/
	
		try
		{
			while (true)
			{
				Person p = (Person) (input.readObject ());
				if (p instanceof Student)
				System.out.println ("I am a student");
				else
				System.out.println ("I am just a normal person");
				System.out.println (p);
				System.out.println ("---------------");
			}
		}
		catch (IOException e)
		{
			System.out.println ("All objects processed");
		}
		catch (ClassNotFoundException e)
		{
			System.err.println ("Wrong casting in objects");
			System.exit (1);
		}
		
		//Closing the file
		try
		{
			if (input != null)
			{
			input.close ();
			System.out.println ("Object file " + fileName
			+ " closed for reading");
			}
		}
		catch (IOException e)
		{
			System.err.println ("Error in closing IO");
			System.exit (1);
		}
	}
	public static void main (String [] args)
	{
		createObjectFile ("infile.ser");
		processObjectFile ("infile.ser");
	}
}

class Person implements Serializable
{
	private String name;
	private int age;
	private char gender;
	
	public Person (String name, int age, char gender)
	{
		this.name = name;
		this.age = age;
		this.gender = gender;
	}
	public String getName ()
	{
		return name;
	}
	public int getAge ()
	{
		return age;
	}
	public char getGender ()
	{
		return gender;
	}
	public String toString ()
	{
		return String.format ("%-15s%n%d %c", name, age, gender);
	}
}

class Student extends Person implements Serializable
{
	private String major;
	public Student (String name, int age, char gender, String major)
	{
		super (name, age, gender);
		this.major = major;
	}
	public String getMajor ()
	{
		return major;
	}
	@Override
	public String toString ()
	{
		return super.toString () + " " + major;
	}
}

/* Begin the creation of Serializable file
Added person James Lim
Added Person Robert Tan
.
.
.
Serializable file infile.ser created
Begin the process of infile.ser
I am just a normal person
James Lim
20 M
-------------
I am just a normal person
Robert Tan
23 M
-------------
I am a student
Lily Lin
28 F Big Data
--------------
All Objects processed
Object file infile.ser closed for reading */



