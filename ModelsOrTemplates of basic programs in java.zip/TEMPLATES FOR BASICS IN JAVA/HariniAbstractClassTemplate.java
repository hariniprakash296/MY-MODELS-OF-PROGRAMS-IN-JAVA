//abstract parent class

abstract class Parent_Class
{
   //abstract method
   public abstract void MethodName();
}

public class Child_Class extends Parent_Class
{

   public void MethodName()
   {
	//enter required code to be executed here
	System.out.println("Excuted code");
   }
   
   public static void main(String args[])
   {
	Parent_Class obj = new Child_Class();
	obj.MethodName();
   }
}
