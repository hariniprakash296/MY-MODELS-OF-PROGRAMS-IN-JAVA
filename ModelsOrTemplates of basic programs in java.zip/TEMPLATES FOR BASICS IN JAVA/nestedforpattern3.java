//nested for loops for printing a pattern in java
/*The pattern is as shown
*
**
***
****
*****
****
***
**
*
*/
class nestedforpattern3{
	public static void main ( String [] args )
	{
		for(int i =1; i<=3; ++i)
		{
			for(int j =i; j>=1; --j)
			{
				System.out.printf("*");
			}
			System.out.println();
		}
		for(int i =1; i<=3; ++i)
		{
			for(int j =i+1; j<=3; ++j)
			{
				System.out.printf("*");
			}
			System.out.println();
		}
	}
}