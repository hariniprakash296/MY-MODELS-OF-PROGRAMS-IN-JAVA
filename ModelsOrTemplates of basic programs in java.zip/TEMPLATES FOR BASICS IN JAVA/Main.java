//Templates to use for finals

//1.base of a program
import java.util.Scanner;
class ClassName
{
	//declaring instance variables (declared as private to demonstrate encapsulation)
	private String a;
	private int b;
	private double c;
	
	//Normal constructor to initialise variables
	public ClassName(String a,int b,double c)
	{
		this.a=a;
		this.b=b;
		this.c=c;
	}
	
	//copy constructor
	public ClassName(ClassName d)
	{
		this.a=d.a;
		this.b=d.b;
		this.c=d.c;
	}
	
	//accessor methods
	public String getA()
	{
		return a;
	}
	public int getB()
	{
		return b;
	}
	public double getC()
	{
		return c;
	}
	
	//setting information
	public void setInfo(String a, int b, double c)
	{
		this.a = a;
		this.b = b;
		this.c = c;
	}
	//method to display information
	public void displayInfo()
	{
		System.out.printf("A: %s",a);
		System.out.printf("B: %d",b);
		System.out.printf("C: %f",c);
		
	}
}

public class Main
{
	public static void main (String [] args)
	{
		//getting input from user using Scanner
		Scanner input = new Scanner(System.in);
		//Asking user for input
		System.out.printf("Enter a String:");
		//We give input.nextLine() to read an entire string and input.next() to read one character alone
		String a = input.nextLine();
		
		System.out.printf("Enter an Integer:");
		int b = input.nextInt();
		
		System.out.printf("Enter a Decimal Number:");
		double c = input.nextDouble();
		
		ClassName Hello = new ClassName(a, b, c);
		Hello.displayInfo();
	}
}
