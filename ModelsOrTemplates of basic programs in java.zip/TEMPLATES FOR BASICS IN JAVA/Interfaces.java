//INTERFACES
// enjoy polymorphism 

//example

import java.util.ArrayList;
interface UsefulFormula
{
	double MYPI = 3.14159256;
	public double area ();
	public double perimeter ();
	public double volume ();
}

//implements the interface classs
abstract class Circle implements UsefulFormula
{
	//declare instance variableA
	protected double radius;
	
	//default constructor
	public Circle()
	{
		radius = 1.0;
	}
	
	public Circle (double radius)
	{
		this.radius = radius;
	}
	
	@Override
	public double area ()
	{
		// Using this from interface 
		return MYPI * radius * radius;
	}
	//@Override
	public double perimeter ()
	{
		// Using this from interface 
		return 2.0 * MYPI * radius;
	}
	// What about volume?
	// - I don't what to do?
	// This is an abstract class
	
	@Override
	public String toString ()
	{
		return String.format ("Circle (%.3f)", radius);
	}
}

//Polymorphism
class TestInterface
	{
	static double getValue ()
	{
		return Math.random () * 100.0 + 0.1;
	}
	public static void main (String [] args)
	{
		// Use of an array alist
		ArrayList <UsefulFormula> alist = new ArrayList <UsefulFormula> ();
	
		//.add function for cylinders and box
		alist.add (new Cylinder (getValue (), getValue ()));
		alist.add (new Cylinder ());
		alist.add (new Box ());
		alist.add (new Box (getValue (), getValue ()));
		alist.add (new Box (getValue (), getValue (), getValue ()));
		for (UsefulFormula uf : alist)
		{
			if (uf instanceof Cylinder)
				System.out.println ("I am a Cylinder");
			else
				System.out.println ("I am a box");
				System.out.println (uf);
				System.out.printf ("Its surface area is %.3f%n", uf.area ());
				System.out.printf ("Its volume is %.3f%n", uf.volume ());
				System.out.println ("---------------------------------");
		}
	}
}