import java.io.File;  // Import the File class
import java.io.IOException;  // Import the IOException class to handle errors


//To create new textfile (myObj is used as myObj.(function on file)


File myObj = new File("filename.txt");

//To create file in specific directory
File myObj = new File("C:\\Users\\MyName\\filename.txt");

//Creating a file with exception handling
import java.io.File;  // Import the File class
import java.io.IOException;  // Import the IOException class to handle errors

//To create a file in Java, you can use the createNewFile() method. 
//This method returns a boolean value: true if the file was successfully created, and false if the file already exists.

public class CreateFile {
  public static void main(String[] args) {
    try {
      File myObj = new File("filename.txt");
	  //here myObj.createNewFile returns true else false
      if (myObj.createNewFile()) {
        //myObj.getName gets name of file
		System.out.println("File created: " + myObj.getName());
      } else {
        System.out.println("File already exists.");
      }
    } catch (IOException e) {
      System.out.println("An error occurred.");
      e.printStackTrace();
    }
  }
}

//######################################################################################################################################################################################################################################################################################

//To write into a file
import java.io.FileWriter;   // Import the FileWriter class
import java.io.IOException;  // Import the IOException class to handle errors

//Code to write into a file
	FileWriter myWriter = new FileWriter("filename.txt");
    myWriter.write("Files in Java might be tricky, but it is fun enough!");
    myWriter.close();

//Writing into a file with ioException
public class WriteToFile {
  public static void main(String[] args) {
    try {
      FileWriter myWriter = new FileWriter("filename.txt");
      myWriter.write("Files in Java might be tricky, but it is fun enough!");
      myWriter.close();
      System.out.println("Successfully wrote to the file.");
    } catch (IOException e) {
      System.out.println("An error occurred.");
      e.printStackTrace();
    }
  }
}

//######################################################################################################################################################################################################################################################################################
//Reading into a file

import java.io.File;  // Import the File class
import java.io.FileNotFoundException;  // Import this class to handle errors
import java.util.Scanner; // Import the Scanner class to read text files

public class ReadFile {
  public static void main(String[] args) {
    try {
      File myObj = new File("filename.txt");
      Scanner myReader = new Scanner(myObj);
      while (myReader.hasNextLine()) {
        String data = myReader.nextLine();
        System.out.println(data);
      }
      myReader.close();
    } catch (FileNotFoundException e) {
      System.out.println("An error occurred.");
      e.printStackTrace();
    }
  }
}

//######################################################################################################################################################################################################################################################################################
//All other methods to get file information from


import java.io.File;  // Import the File class

public class GetFileInfo { 
  public static void main(String[] args) {
    File myObj = new File("filename.txt");
    if (myObj.exists()) {
      System.out.println("File name: " + myObj.getName());
      System.out.println("Absolute path: " + myObj.getAbsolutePath());
      System.out.println("Writeable: " + myObj.canWrite());
      System.out.println("Readable " + myObj.canRead());
      System.out.println("File size in bytes " + myObj.length());
    } else {
      System.out.println("The file does not exist.");
    }
  }
}