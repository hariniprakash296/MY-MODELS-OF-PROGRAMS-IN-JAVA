//factorial

import java.util.stream.*; 
class factorial
{
	public static long factorialUsingStreams(int n) 
		{
			return LongStream.rangeClosed(1, n)
			.reduce(1, (long x, long y) -> x * y);
		}
	public static void main(String[] args)
	{
		long a = factorialUsingStreams(5);
		System.out.printf("%d%n",a);
	}
}