//nested for loops for printing a pattern in java
/*The pattern is as shown
*
**
***
****
*****
*/
class nestedforpattern1{
	public static void main ( String [] args )
	{
		for(int i =1; i<=3; ++i)
		{
			for(int j =i; j>=1; --j)
			{
				System.out.printf("*");
			}
			System.out.println();
		}
	}
}