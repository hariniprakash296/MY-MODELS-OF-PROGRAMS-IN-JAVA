//LAMBDA TEMPLATES 2


//Another example
class TestArrayStream
{
    // this is an array of objects
	static Integer [] a = {3, 4, 6, 2, -1, -8, 3, 7, 9, 2};
	static void example_1 ()
	{
	
	// this is to store the array as List
	List <Integer> alist = Arrays.asList (a);
	System.out.println (alist);
	
	// this is to help sort and store in sorted list
	List <Integer> sortedList = Arrays.stream (a)
	.sorted ()
	.collect (Collectors.toList ());
	System.out.println (sortedList);
	
	// this is to put the value greater than k (2) inside the list
	List <Integer> alist2 = Arrays.stream (a)
	.filter (x -> x > 2)
	.sorted ()
	.collect (Collectors.toList ());
	System.out.println (alist2);
	}
	
	//output
	//[3, 4, 6, 2, -1, -8, 3, 7, 9, 2]
	//[-8, -1, 2, 2, 3, 3, 4, 6, 7, 9]
	//[3, 3, 4, 7, 9]
	
	// this is to sort the list
	List <Integer> alist = Arrays.asList (a);
	Collections.sort (alist);
	System.out.println (alist);
	
	// this is to shuffle the list
	Collections.shuffle (alist);
	System.out.println (alist);
	
	//output
	//[-8, -1, 2, 2, 3, 3, 4, 6, 7, 9]
	//[-8, 4, 7, 9, -1, 3, 2, 6, 2, 3]
	
	
	static String s [] = {"H2", "D5", "S3", "H6", "H3","C2", "H5", "D3", "D6", "C3"};
	
	// change the playing cards to LOWERCASE
	//DO TAKE note of the use of :: in map
	List <String> alist = Arrays.stream (s)
					.map (String::toLowerCase)
					.collect (Collectors.toList ());
					
	System.out.println (alist);
	// this is the ones Heart (H) only list
	List <String> alist1 = Arrays.stream (s)
						.filter (x -> x.charAt (0) == 'H')
						.collect (Collectors.toList ());
	System.out.println (alist1);
	
	//output
	//[h2, d5, s3, h6, h3, c2, h5, d3, d6, c3]
	//[H2, H6, H3, H5]
	
	
	//Another example
	Double [] doubleArray = {2.3, 4.5, 7.8, 22.5, 88.9};
	
	// this is to find the square root of all objects in List
	List <Double> alist = Arrays.stream (doubleArray)
					.map (Math::sqrt)
					.collect (Collectors.toList ());
	
	System.out.println (alist);
	
	//output
	//[1.5165750,2.1224323423, 2.792342342, 4.7425424234, 9.4234242342]

}

//making use of ::
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
class Square
{
	private int side;
	public Square (int side)
	{
		this.side = side;
	}
	public String toString ()
	{
		return "Square (" + side + ")";
	}
}

class TestTwoColons_2
{
	public static void main (String [] args)
	{
	Square [] sq = {new Square (3), new Square (6), new Square (8)};
	Arrays.stream (sq)
		.forEach (System.out::println);
	}
}

//Square (3)
//Square (6)
//Square (8)
