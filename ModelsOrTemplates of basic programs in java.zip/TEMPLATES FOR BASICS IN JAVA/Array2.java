class Rectangle{
	private double length;
	private double breadth;
	
	//constructor
	public Rectangle(double length, double breadth)
	{
		this.length = length;
		this.breadth = breadth;
	}
	
	//default constructor
	public Rectangle()
	{
		length = 0;
		breadth = 1;
	}
	
	//accessor methods
	public double getLength()
	{
		return length;
	}
	public double getBreadth()
	{
		return breadth;
	}
	
	//mutator methods
	public void setInfo(double length, double breadth)
	{
		this.breadth = breadth;
		this.length = length;
	}
	
	private double area()
	{
		return breadth*length;
	}
	
	public void printInfo()
	{
		System.out.printf("Length: %.2f Breadth: %.2f%n",getLength(),getBreadth());
		System.out.printf("Area of rectangle is : %.2f%n",area());
		System.out.println();
	}
}

class Array2
{
	private static String LINE ="--------------------------------------------------------------";
	public static void main (String [] args)
	{
		Rectangle [] array = new Rectangle[5];
		//This is to create elements in each position in the array
		for (int i = 0; i < array.length;i++)
		{
			array [i] = new Rectangle();
			array [i].printInfo();
		}
		
		System.out.println();
		System.out.println(LINE);
		System.out.println();
		//This is to add a value to every element created
		Rectangle [] c = {new Rectangle (Math.random () * 1.0 + 9.0, Math.random () * 1.0 + 9.0),
						new Rectangle (Math.random () * 1.0 + 9.0, Math.random () * 1.0 + 9.0), 
						new Rectangle (Math.random () * 1.0 + 9.0, Math.random () * 1.0 + 9.0), 
						new Rectangle (Math.random () * 1.0 + 9.0, Math.random () * 1.0 + 9.0),
						new Rectangle (Math.random()* 1.0 +0.0, Math.random() * 1.0 + 9.0)
						};
		for (int j = 0; j < c.length; j++)
		{
			c [j].printInfo();
		}		
	}
}