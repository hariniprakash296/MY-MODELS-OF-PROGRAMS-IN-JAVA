import javax.swing.JOptionPane;
class JOP_displayString 
{
 public static void main (String [] args)
 {
	String str = JOptionPane.showInputDialog ("Display this before textbox");
	String a = str; 
	str = "Display in message dialogue " + a;
 
	// Display the output dialog box 
	JOptionPane.showMessageDialog (null, str, "Rectangle example",JOptionPane.INFORMATION_MESSAGE);
 
 } // end of main 
} // end of class