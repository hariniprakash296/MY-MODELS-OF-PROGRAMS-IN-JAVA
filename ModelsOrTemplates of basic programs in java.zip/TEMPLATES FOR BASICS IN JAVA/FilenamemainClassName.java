////Base GUI Template


import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import java.awt.FlowLayout;
import java.awt.Font;

public class FilenamemainClassName extends JFrame {
	private JLabel lblName;    // Declare a Label component
	private JTextField tfCount; // Declare a TextField component
	private final JLabel lblimage;//Declare a JLabel
	
	// Constructor to setup GUI components and event handlers
	public FilenamemainClassName () {
		// "super" Frame, which is a Container, sets its layout to FlowLayout to arrange
        // the components from left-to-right, and flow to next row from top-to-bottom.
		// "super" Frame sets its initial window size
		super("THIS IS THE FRAME");
		
		setLayout(new FlowLayout());
		setVisible(true);         // "super" Frame shows
		
		setTitle("TITLE:");  // "super" Frame sets its title
		
		//Name label and textfield for name being created
		lblName = new JLabel("LABEL NAME:");  // construct the Label component
		lblName.setFont(new Font("Calibri", Font.BOLD, 13));
		add(lblName);                    // "super" Frame container adds Label component
		
		tfCount = new JTextField("TEXT IN TEXTBOX",30); // construct the TextField component with initial text
		tfCount.setEditable(false);       // set to read-only
		add(tfCount);                     // "super" Frame container adds TextField component
		tfCount.setText("TEXT IN TEXTBOX");	
		
		//Image label and image display being created
		Icon a = new ImageIcon("a.jpg");
		lblimage = new JLabel();
		
		//Setting tooltiptext
		lblimage.setToolTipText("TEXT DESCRIBING IMAGE");
		lblimage.setIcon(a);
		add(lblimage);		
	}	

	// The entry main() method
	public static void main(String[] args) {
      // Invoke the constructor to setup the GUI, by allocating an instance
		FilenamemainClassName app = new FilenamemainClassName();
		app.setSize(465, 500); 
		app.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
   }
}
