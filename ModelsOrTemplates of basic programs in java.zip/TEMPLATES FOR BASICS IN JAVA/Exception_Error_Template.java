//Exception Error

import java.util.InputMismatchException;
import java.lang.ArithmeticException;

//example 
public static void main (String [] args)
{
	Scanner input = new Scanner (System.in);
	boolean ok = true;
	do
	{
		try
		{
			System.out.print ("Enter an integer for numerator: ");
			int numerator = input.nextInt ();
			System.out.print ("Enter an integer for denominator: ");
			int denominator = input.nextInt ();
			int result = quotient (numerator, denominator);
			System.out.println ("The quotient is " + result);
			ok = true;
		}
		//ArithmeticException (ERROR MESSAGE)
		catch (ArithmeticException e)
		{
			System.out.print ("Exception message: ");
			System.out.println (e);
		}
		//InputMismatchException (ERROR MESSAGE)
		catch (InputMismatchException e)
		{
			System.out.print ("Exception message: ");
			System.out.println (e);
			ok = false;
			input.nextLine ();
			System.out.println ("------------");
		}
		} while (ok == false);
		System.out.println ("I still can do something outside");
	}
}

//Now we are using Try-Catch-Finally

public class UsingException {
	public static void main (String [] args)
	{
		try
		{
			throwException ();
		}
		catch (Exception e)
		{
			System.err.println ("Exception handled in main");
		}
		doesNotThrowException ();
	}
	
	
	public static void throwException () throws Exception
	{
		// we are using the try function
		try
		{
			System.out.println ("Method throwException");
			throw new Exception ();
		}
		
		//we are using the catch function
		catch (Exception e)
		{
			System.err.println ("Exception handled in method throwException");
			throw e;
		}
		
		// we using the finally function
		finally 
		{
			System.err.println ("Finally executed in throwException");
		}
	}
	
	//displaying the error messages
	public static void doesNotThrowException ()
	{
		try
		{
			System.out.println ("Method doesNotThrowException");
		}
		catch (Exception e)
		{
			System.err.println (e);
		}
		finally
		{
			System.out.println ("Finally executed in doesNotThrowException");
		}
		System.out.println ("End of method doesNotThrowException");

	}
	
	// Array out of bounds exception error 
	public static void main (String [] args)
	{
		try
		{
			methodA ()
		}
		
		//catch (Exception error)
		//ArrayIndexOutOfBoundsException
		catch (ArrayIndexOutOfBoundsException error)
		{
			error.printStackTrace ();
		}
	}
	public static void methodA ()
	{
		System.out.println ("In methodA()");
		methodB (); 
	}
	public static void methodB()
	{
		System.out.println ("In methodB()");
		methodC (); 
	}
	public static void methodC ()
	{
		System.out.println ("In methodC()");
		int [] array = {0, 1, 2};
		//it is our of array index
		System.out.println (array [4]); 
	}
	
	// output error message
	//java.lang.ArrayIndexOutOfBoundsException: 4
    //demoStackStrace.methodC(DemoStrackTrace.java:32)
	//demoStackStrace.methodB(DemoStrackTrace.java:32)
	//demoStackStrace.methodA(DemoStrackTrace.java:32)


// User Defined Execeptions 
// if 
//	throw newExceptions
//(GOT THIS EXAMPLE FROM CLASS EXAMPLES )

import java.util.Random;
class TestException
{
	public void assess (int exam) throws NotHappyException,HappyException
	{
		//with different makrs the exception is included
		if (exam < 50)
			throw new NotHappyException ();
		else if (exam < 65)
			throw new HappyException ();
		else if (exam < 75)
			throw new HappyException ("I scored a Credit");
		else if (exam < 85)
			throw new HappyException ("I scored only a Dist");
		else
			throw new HappyException ("Wow!! I scored a HDist");
	}
	
	public static void main (String [] args)
	{
		Random rand = new Random();
		TestException t = new TestException();
		
		int exam;
		
		for (int i = 1; i<=5;i++)
		{
			try
			{
				exam = Math.abs (rand.nextInt ()) % 101;
				System.out.print ("your exam = " + exam + " ==> ");
				t.assess (exam);
			}
			catch (NotHappyException e)
			{
				e.printMessage ();
				System.out.println ();
			}
			catch (HappyException e)
			{
				e.printMessage ();
				System.out.println ();
			}
		}
	}
}

class NotHappyException extends Exception
	{
		private String msg;
		NotHappyException ()
		{
			msg = "I failed the exam";
		}
		
		void printMessage ()
		{
		System.out.print (msg);
		}
	}

class HappyException extends Exception
{
	private String msg;
	
	HappyException ()
	{
		msg = "I passed the exam";
	}
	HappyException (String msg)
	{
		this.msg = msg;
	}
	void printMessage ()
	{
		System.out.print (msg);
	
	}
}

//output
// your exam = 66 ==> I scored a Credit
// your exam = 29 ==> I failed the exam
// your exam = 1 ==> I failed the exam
// your exam = 3 ==> I failed the exam
// your exam = 57 ==> I scored a Credit