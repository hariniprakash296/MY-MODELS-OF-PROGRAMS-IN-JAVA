//fibonacci with recursion
class forloop{
	public static void main (String [] args)
	{
		int i;
		for(i=3;i>0;i--)
		{
			System.out.println(i);
		}
	}
}