import javax.swing.JOptionPane;
class JOP_displayDouble 
{
 public static void main (String [] args)
 {
	String str = JOptionPane.showInputDialog ("Display this before textbox");
	double a = Double.parseDouble (str); 
	str = "Display in message dialogue " + a;
 
	// Display the output dialog box 
	JOptionPane.showMessageDialog (null, str, "Rectangle example",JOptionPane.INFORMATION_MESSAGE);
 
 } // end of main 
} // end of class